import scrapy
from Tools.scripts import ifdef
from scrapy.http import request
from scrapy.http.request.form import FormRequest
from scrapy.http import FormRequest
import json
from scrapy.spidermiddlewares.httperror import HttpError
from twisted.internet.error import DNSLookupError
from twisted.internet.error import TimeoutError, TCPTimedOutError
import time
from http.cookies import SimpleCookie

class CarPricesCarsSpider(scrapy.Spider):
    name = 'car_prices_shift'
    allowed_domains = ['shift.com']
    meta_data = ''
    proxy = 'http://dvafvogc:c75babt2ovb6@45.158.187.187:7196'

    def start_requests(self):
        captcha_solving_task_creation_response = yield scrapy.http.JsonRequest(
            url='https://api.capsolver.com/createTask',
            headers={
                'Accept': '*/*',
                'Content-Type': 'application/json',
            },
            data={
                'clientKey': 'CAI-B4FFF136581A0240260C4C4B8B4C0381',
                'task': {
                    'type': 'DatadomeSliderTask',
                    'websiteURL': f'https://shift.com/api/consumer/v1/lp_vin_details?vin={self.vin.upper()}',
                    'captchaUrl': 'https://geo.captcha-delivery.com/captcha/?initialCid=AHrlqAAAAAMA_VBUvSlCUysAerIrfQ==&cid=0DZsUI2lEkciy39BZTqiNbAtljNlIlgQ066xTSonkwSgU-9s7QTX_02IxtxvtDsB1_MZKO7BCyuEvRe6JksxnDM9LwUF~XTAV4dp9hdcUs3VzXPxWyswNdlWi5CHEuEY&referer=http%3A%2F%2Fshift.com%2Fapi%2Fconsumer%2Fv1%2Flp_vin_details%3Fvin%3DSALVP2RX1JH284344&hash=2065822642B818FC6FB69F4B5EA4A4&t=fe&s=36395&e=15cbc0399ea4e863ce84e328b241df8ab14a892c38efc33f50ca5ea064a5d681',
                    "proxy": "socks5:185.102.50.102:7185:dvafvogc:c75babt2ovb6",
                    "userAgent": "'Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"

                },
            },
            callback=self.parse_json_response1,
        )
        self.logger.info('=======captcha_solving_task_creation_response= {}'
                         .format(captcha_solving_task_creation_response))

    def parse_json_response1(self, response):
        json_response = response.json()
        captcha_solving_task_creation_response = json_response
        self.logger.info('=======parse_json_response= {}'.format(json_response))
        captcha_solving_task_id = captcha_solving_task_creation_response['taskId']
        self.logger.info('=======captcha_solving_task_id= {}'.format(captcha_solving_task_id))
        captcha_solution_token = None
        while (captcha_solution_token is None):
            time.sleep(20)
            captcha_solving_task_status_response = yield scrapy.http.JsonRequest(
                method="POST",
                url='https://api.capsolver.com/getTaskResult',
                headers={
                    'Accept': '*/*',
                    'Content-Type': 'application/json',
                },
                data={
                    'clientKey': 'CAI-B4FFF136581A0240260C4C4B8B4C0381',
                    'taskId': captcha_solving_task_id,
                },
                callback=self.capsolver_final_response,
                dont_filter=True,
            )

            self.logger.info('====IsSideWhileLoop===captcha_solving_task_status_response= {}'
                             .format(captcha_solving_task_status_response))
            # if captcha_solving_task_status_response['errorId'] > 0:
            #     raise RuntimeError(captcha_solving_task_status_response['errorDescription'])

            if captcha_solving_task_status_response['status'] == 'ready':
                captcha_solution_token = captcha_solving_task_status_response
        #
        # self.logger.info('====captcha_solution_token= {}'.format(captcha_solution_token))

    def capsolver_final_response(self, response):
        json_response = response.json()
        captcha_solving_task_creation_response = json_response
        self.logger.info('====jsonresponse===capsolver_final_response= {}'.format(json_response))

        vin_request = scrapy.http.JsonRequest(
            url=f'https://shift.com/api/consumer/v1/lp_vin_details?vin={self.vin.upper()}',
            method='GET',
            headers={
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Content-Type': 'text/json',

            },
            callback=self.actual_data_response,
        )

        cookie = SimpleCookie()
        cookie.load(json_response['solution']['cookie'])
        cookie_dict = {k: v.value for k, v in cookie.items()}
        self.logger.debug(cookie_dict)
        vin_request.cookies = cookie_dict
        yield vin_request

    def actual_data_response(self, response):
        json_response = response.json()
        captcha_solving_task_creation_response = json_response
        self.logger.info('=======actual_data_response= {}'.format(json_response))

    def parse_json_response(self, response):
        json_response = response.json()
        captcha_solving_task_creation_response = json_response
        self.logger.info('=======parse_json_response= {}'.format(json_response))
        captcha_solving_task_id = captcha_solving_task_creation_response['taskId']

        captcha_solution_token = None
        while (captcha_solution_token is None):
            time.sleep(3)
            captcha_solving_task_status_response = yield scrapy.http.JsonRequest(
                method="POST",
                url='https://api.capsolver.com/getTaskResult',
                headers={
                    'Accept': '*/*',
                    'Content-Type': 'application/json',
                },
                data={
                    'clientKey': 'CAI-B4FFF136581A0240260C4C4B8B4C0381',
                    'taskId': captcha_solving_task_id,
                },
                callback=self.parse_json_response,
                dont_filter=True,
            )

            self.logger.info('====IsSideWhileLoop===captcha_solving_task_status_response= {}'
                             .format(captcha_solving_task_status_response))
            if captcha_solving_task_status_response['errorId'] > 0:
                raise RuntimeError(captcha_solving_task_status_response['errorDescription'])

            if captcha_solving_task_status_response['status'] == 'ready':
                captcha_solution_token = captcha_solving_task_status_response['solution']['gRecaptchaResponse']

        self.logger.info('====captcha_solution_token= {}'.format(captcha_solution_token))

        captcha_solution_submission_response = yield scrapy.http.JsonRequest(
            url=f'https://shift.com/api/consumer/v1/lp_vin_details?vin={self.vin.upper()}',
            headers={
                'accept': '*/*',
                'accept-language': 'en-US,en;q=0.9',
                'referer': 'https://shift.com/sell-my-car',
                'sec-ch-ua': 'Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'User-Agent': 'Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148',
                'accept': 'application/json',
            },
            data={
                "ResponseToken": captcha_solution_token,
                # "ResponseToken": 'gRecaptchaResponse":"03AFY_a8ULO58W09ibFvFX4OuhKRBdB--vUsbcJLtGg_4q8oh74AnaPXeufx8erBXnO4VLOwSbb0Lb6wqwpXhspV0rNNLuVQSnVVRHeApbfZPO8cBYS23ViX2kYd_RZOxmt2LUYkLdbMdS_xuGnwzUOnyCNzuBrigPylBJ0GvHEN_tAQqlgRiBw4j2KWVwemlKCQ0uqJjXb0k3qW_b21AuIwbYy37wKFS1BiSrfAGjOdu692n11qrFlNO1yOpH2vKw093dPHWiz2UokjLa04r_COzoBciyfomGGg-xCL5Fhr9_sK4XHiTrAKjjHC1_Uw1iSqY_YB5efcL6RQ483GhsU8PFUBev1B9F6sBFSdWNedUqYXV9i0PgxVCY9WPc9WEk2ql3I7PgA_vXzMQEYbguTi40P0lVJitiKRtvq1qW-u6NpPzgUASpkyqa7AVm2Zi5dbNvV8bQu6lYV3kz1GkY0ZYzMnVTPa5w2FFlcVBUjcTtLQkTLBDn0-ng1ZQINFhv0ZIQVdJn7xU62F1eOk1A-hQDBf6NlyfSN2pIQQTnyJHCBVfSxYmd50_J0vl4nktGzz8w-1RyRCrbGg4t44Y4KXKIIM3gDYXuNl_hCrTBRn_1J2ha2XHT1Mw',
            },
            callback=self.parse_json_response,
        )

        form_data = {}
        yield scrapy.Request(
            url=f'https://shift.com/api/consumer/v1/lp_vin_details?vin={self.vin.upper()}',
            headers={
                'accept': '*/*',
                'accept-language': 'en-US,en;q=0.9',
                'referer': 'https://shift.com/sell-my-car',
                'sec-ch-ua': 'Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-origin',
                'User-Agent': 'Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148',
                'accept': 'application/json',
            },
            callback=self.vehicle_lookup_parse,
            errback=self.errback_httpbin,
            meta={
                'proxy': self.proxy,
            },
        )

    def vehicle_lookup_parse(self, response):
        json_response = response.json()
        self.logger.info('=======vehicle_lookup_parse===response.headers=== {}'.format(json_response))
        result = json_response

    # Error Handling
    def errback_httpbin(self, failure):
        # log all failures
        self.logger.error(repr(failure))

        # in case you want to do something special for some errors,
        # you may need the failure's type:

        if failure.check(HttpError):
            # these exceptions come from HttpError spider middleware
            # you can get the non-200 response
            response = failure.value.response
            self.logger.error('ErrorHandling===HttpError on %s', response.url)
            self.logger.error('ErrorHandling===HttpError on Headers %s', response.headers)
            self.logger.error('ErrorHandling===HttpError on Body %s', response.body)

        elif failure.check(DNSLookupError):
            # this is the original request
            request = failure.request
            self.logger.error('ErrorHandling===DNSLookupError on %s', request.url)

        elif failure.check(TimeoutError, TCPTimedOutError):
            request = failure.request
            self.logger.error('ErrorHandling===TimeoutError on %s', request.url)
